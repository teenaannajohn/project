<script>
    const text = function() {
    document.querySelector("#addqus").style.display = "none";
    document.querySelector("#ques").style.display = "none";
    document.querySelector("#ques").style.display = "none";
    document.querySelector("#btn2").style.display = "none";
    document.querySelector("#btn3").style.display = "none";
    document.querySelector("#btn4").style.display = "none";
    document.querySelector("#btn5").style.display = "none";

     document.querySelector("#rd1").addEventListener('click', function () {
         document.querySelector("#btn1").style.display = "block";
         document.querySelector("#btn3").style.display = "none";
         document.querySelector("#btn2").style.display = "none";
         document.querySelector("#btn4").style.display = "none";
         document.querySelector("#btn5").style.display = "none";
         document.querySelector("#addqus").style.display = "none";
         document.querySelector("#ques").style.display = "none";
     });
     document.querySelector("#rd2").addEventListener('click', function () {
        document.querySelector("#btn1").style.display = "none";
        document.querySelector("#btn3").style.display = "none";
        document.querySelector("#btn2").style.display = "block";
        document.querySelector("#btn4").style.display = "none";
        document.querySelector("#btn5").style.display = "none";
        document.querySelector("#addqus").style.display = "none";
        document.querySelector("#ques").style.display = "none";
     });
     document.querySelector("#rd3").addEventListener('click', function () {
        document.querySelector("#btn1").style.display = "none";
        document.querySelector("#btn2").style.display = "none";
        document.querySelector("#btn3").style.display = "block";
        document.querySelector("#btn4").style.display = "none";
        document.querySelector("#btn5").style.display = "none";
        document.querySelector("#addqus").style.display = "none";
        document.querySelector("#ques").style.display = "none";
     });
     document.querySelector("#rd4").addEventListener('click', function () {
        document.querySelector("#btn1").style.display = "none";
        document.querySelector("#btn2").style.display = "none";
        document.querySelector("#btn3").style.display = "none";
        document.querySelector("#btn4").style.display = "block";
        document.querySelector("#btn5").style.display = "none";
        document.querySelector("#addqus").style.display = "none";
        document.querySelector("#ques").style.display = "none";
     });
     document.querySelector("#rd5").addEventListener('click', function () {
        document.querySelector("#btn1").style.display = "none";
        document.querySelector("#btn2").style.display = "none";
        document.querySelector("#btn3").style.display = "none";
        document.querySelector("#btn4").style.display = "none";
        document.querySelector("#btn5").style.display = "block";
        document.querySelector("#addqus").style.display = "none";
        document.querySelector("#ques").style.display = "none";
     });
     document.querySelector("#addque").addEventListener('click', function () {
        document.querySelector("#btn1").style.display = "none";
        document.querySelector("#btn2").style.display = "block";
        document.querySelector("#btn3").style.display = "none";
        document.querySelector("#btn4").style.display = "none";
        document.querySelector("#btn5").style.display = "none";
        document.querySelector("#ques").style.display = "none";
        document.querySelector("#addqus").style.display = "block";
     });
     document.querySelector("#qp").addEventListener('click', function () {
        document.querySelector("#btn1").style.display = "none";
        document.querySelector("#btn2").style.display = "block";
        document.querySelector("#btn3").style.display = "none";
        document.querySelector("#btn4").style.display = "none";
        document.querySelector("#btn5").style.display = "none";
        document.querySelector("#addqus").style.display = "none";
        document.querySelector("#ques").style.display = "block";
     });
 }

 text();
</script>
