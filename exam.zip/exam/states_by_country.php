<?php
require_once "db.php";
$country_id = $_POST["country_id"];
echo $result = mysqli_query($conn,"SELECT * FROM subjects where sem = $country_id");
?>
<option value="">Select State</option>
<?php
while($row = mysqli_fetch_array($result)) {
?>
<option value="<?php echo $row[1];?>"><?php echo $row[1];?></option>
<?php
}
?>