<?php

include('db.php');

$countryId = isset($_POST['countryId']) ? $_POST['countryId'] : 0;
$stateId = isset($_POST['stateId']) ? $_POST['stateId'] : 0;
$command = isset($_POST['get']) ? $_POST['get'] : "";

switch ($command) {
    case "country":
        $statement = "SELECT sem_id,sem FROM semester";
        $dt = mysqli_query($conn, $statement);
        while ($result = mysqli_fetch_array($dt)) {
            echo $result1 = "<option value=" . $result['sem_id'] . ">" . $result['sem'] . "</option>";
        }
        break;

    case "state":
        $result1 = "<option>Select State</option>";
        $statement = "SELECT * FROM subjets WHERE sem='$countryId";
        $dt = mysqli_query($conn, $statement);

        while ($result = mysqli_fetch_array($dt)) {
            $result1 .= "<option value=" . $result['subid'] . ">" . $result['subject'] . "</option>";
        }
        echo $result1;

        break;

    case "city":
        $result1 = "<option>Select City</option>";
        $statement = "SELECT subid, subject FROM subjects WHERE sem=" . $stateId;
        $dt = mysqli_query($conn, $statement);

        while ($result = mysqli_fetch_array($dt)) {
            $result1 .= "<option value=" . $result['id'] . ">" . $result['name'] . "</option>";
        }
        echo $result1;
        break;
}

exit();
?>