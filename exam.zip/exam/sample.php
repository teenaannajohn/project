<?php  
function fetch_data2()  
{  
    $genqp_sub=$_POST['genqp_sub'];
    $essay=$_POST['essay'];
    $from_mod=$_POST['from_mod'];
    $to_mod=$_POST['to_mod']; 
    $count=0;
    $output = '';  
    $connect = mysqli_connect("localhost", "root", "", "exam","4306"); 
    $sql = "SELECT * FROM question_paper where q_subject='$genqp_sub' and q_qtype='essay' and module between 
    $from_mod and $to_mod ORDER BY RAND()LIMIT $essay";  
     $result = mysqli_query($connect, $sql);  
     while($row = mysqli_fetch_array($result))  
     {     
     $count++;  
     $output .= '
                        <table border="1" cellspacing="0" cellpadding="5"> 
                         <tr>  
                         <td style="width:50px;">'.$count.'</td>  
                         <td style="width:400px;text-align:left!important;">'.$row["q_question"].'</td>  
                         <td style="width:50px">10</td>  
                         <td style="width:50px">'.$row["q_klevel"].'</td>  
                         <td style="width:58px">'.$row["q_coklevel"].'</td>  
                    </tr>
                    </table>  
                         ';  
     }  
     return $output;  
}  
 function fetch_data()  
 {  
    $count=0;
    $short=$_POST['short'];
    $genqp_sub=$_POST['genqp_sub'];
    $from_mod=$_POST['from_mod'];
    $to_mod=$_POST['to_mod']; 
    $output = '';  
    $connect = mysqli_connect("localhost", "root", "", "exam","4306"); 
     $sql = "SELECT * FROM question_paper where q_subject='$genqp_sub' and q_qtype='short' and module between $from_mod and $to_mod ORDER BY RAND()LIMIT $short";  
      $result = mysqli_query($connect, $sql);  
      while($row = mysqli_fetch_array($result))  
      {  
      $count++;       
      $output .= '<tr>  
                          <td>'.$count.'</td>  
                          <td style="text-align:left!important;">'.$row["q_question"].'</td>  
                          <td>3</td>  
                          <td>'.$row["q_klevel"].'</td>  
                          <td>'.$row["q_coklevel"].'</td>  
                     </tr>  
                          ';  
      }  
      return $output;  
 }  
 if(isset($_POST["create_pdf"]))  
 {  
      require_once('tcpdf/tcpdf.php'); 
      $width = 250;  
$height = 600;
      $custom_layout = array($width, $height); 
      $obj_pdf = new TCPDF('P', PDF_UNIT, $custom_layout, true, 'UTF-8', false);  
      $obj_pdf->SetCreator(PDF_CREATOR);  
      $obj_pdf->SetTitle("QUESTION PAPER");  
      $obj_pdf->SetHeaderData('', '', PDF_HEADER_TITLE, PDF_HEADER_STRING);  
      $obj_pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));  
      $obj_pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));  
      $obj_pdf->SetDefaultMonospacedFont('helvetica');  
      $obj_pdf->SetFooterMargin(PDF_MARGIN_FOOTER);  
      $obj_pdf->SetMargins(PDF_MARGIN_LEFT, '5', PDF_MARGIN_RIGHT);  
      $obj_pdf->setPrintHeader(false);  
      $obj_pdf->setPrintFooter(false);  
      $obj_pdf->SetAutoPageBreak(TRUE, 10);  
      $obj_pdf->SetFont('helvetica', '', 12);  
      $obj_pdf->AddPage();  
      $content = '';  
      $content .= '  

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<img src="images/clg_logo.jpg" style="display: block;margin: 0 auto;" >
<h2 align="center" >DEPARTMENT OF MCA</h2>
<h4 align="center">First Internal Assessment Examination-DEC 2021</h4>
<h5 align="center">First Semester MCA</h5>
<h5 align="center">20MCA278-MATHEMATICAL FOUNDATIONS OF COMPUTING</h5>
<h4 align="center">PART A(3*10=30)&nbsp;&nbsp;&nbsp;ANSWER ALL QUESTIONS
<br>
      <table border="1" cellspacing="0" cellpadding="5">  
      <tr>
      <th style="width:50px">Q.No</th>
      <th style="width:400px">Questions</th>
      <th style="width:50px">Marks</th>
      <th style="width:50px">K Level</th>
      <th style="width:58px">CO & K Level </th>
    </tr>
      ';  
      $content .= fetch_data();  
      $content .= '</table><br>';
      $content .= '<h4 align="center">PART A(3*10=30)&nbsp;&nbsp;&nbsp;ANSWER ANY 2 QUESTIONS<br>';
      $content .= fetch_data2(); 
      // $content .= '</table>';
      $obj_pdf->writeHTML($content);  
      $obj_pdf->Output('sample.pdf', 'I');  
 }  
 ?> 
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<link href="login_css.css" rel="stylesheet" id="login-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="teacher_home_css.css">
    <!-- Fonts -->
    <link rel="dns-prefetch" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Raleway:300,400,600" rel="stylesheet" type="text/css">

    <link rel="stylesheet" href="css/style.css">

    <link rel="icon" href="Favicon.png">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">

    <title>EMS</title>

</head>
<body>

<nav class="navbar navbar-expand-lg navbar-light navbar-laravel">
    <div class="container">
        <img src="images/icon.png" width="80px">
        <a class="navbar-brand" href="#">AEMS</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
<?php
if(isset($_GET["msg"]))
{
    if($_GET["msg"]==0)
    {
    ?>
    <script>
    swal("TIME TABLE ADDED SUCCESSFULLY", "", "success");
    </script>
    <?php
    }
    if($_GET["msg"]==1)
    {
        ?>
    <script>
     swal("SOMETHING WENT WRONG", "PLEASE WAIT...");
     </script>
        <?php
    }
    if($_GET["msg"]==2)
    {
    ?>
    <script>
    swal("QUESTIONS ADDED SUCCESSFULLY", "", "success");
    </script>
    <?php
    }

}
?>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                <input type="submit" id="rd1" class="btn btn-primary" value="MY HOME">
                </li>&nbsp;&nbsp;&nbsp;&nbsp;
                 <li class="nav-item">
                 <input type="submit" id="rd2" class="btn btn-primary" value="QUESTION PAPER SETTINGS">
                </li> 
                &nbsp;&nbsp;&nbsp;&nbsp;
                 <li class="nav-item">
                 <input type="submit" id="rd3" class="btn btn-primary" value="UPDATE RESULTS">
                </li>
                &nbsp;&nbsp;&nbsp;&nbsp;
                 <li class="nav-item">
                 <input type="submit" id="rd4" class="btn btn-primary" value="TIMETABLE SETTINGS">
                </li> 
                &nbsp;&nbsp;&nbsp;&nbsp;
                 <li class="nav-item">
                 <input type="submit" id="rd5" class="btn btn-primary" value="NOTIFICATIONS">
                </li>  
            </ul>

        </div>
    </div>
</nav>
<main class="login-form">
    <div class="cotainer" id="#reg">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    

                    <div id="btn1">
                        <div class="card-header">MY HOME</div> 
                        <H2 style=" text-align: center;">WELCOME TEACHER</H2>
                                <div style=" text-align: center;">
                                <img src="images/teacherhome.png" style="width: 50%;">
                                </div>
                    </div>
    
    
                                <div id="btn2">
                                <div class="card-header">QUESTION PAPER SETTINGS</div>
                                <div id = "add">
                                <div class="col-md-9 offset-md-4">
                                <input type="submit"  id="addque" name="addque" class="btn btn-warning" value="ADD QUESTIONS">
                                <input type="submit"  id="qp" name="qp" class="btn btn-warning" value="GENERATE QUESTION PAPER">
                                </div>
                        
                                </div>
                                </div>


<!-- update result -->
                                <div id="btn3">
                                <div class="card-header">UPDATE RESULTS</div>
                                <div class="form-group row" >
                                            <label for="stud_sem" class="col-md-4 col-form-label text-md-right">SEMESTER</label>
                                            <div class="col-md-6">
                                            <select name="student_sem" id="student_sem" class="form-control">
                                              <option value="S1">S1</option>
                                              <option value="S2">S2</option>
                                              <option value="S3">S3</option>
                                              <option value="S4">S4</option>
                                              <option value="S5">S5</option>
                                              <option value="S6">S6</option>
                                            </select>
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label for="stud_sem" class="col-md-4 col-form-label text-md-right">SUBJECT</label>
                                            <div class="col-md-6">
                                            <select name="student_sem" id="student_sem" class="form-control">
                                              <option value="S1">MATHEMATICAL FOUNDATIONS OF COMPUTING</option>
                                              <option value="S2">DIGITAL FUNDAMENTALS OF COMPUTER ARCHITECTURE</option>
                                              <option value="S3">ADVANCED DATA STRUCTURES</option>
                                              <option value="S4">SOFTWARE ENGINEERING</option>
                                              <option value="S5">WEB PROGRAMMING</option>
                                              <option value="S6">PYTHON LAB</option>
                                            </select>
                                            </div>
                                        </div>  

                                        <div class="form-group row">
                                            <label for="stud_sem" class="col-md-4 col-form-label text-md-right"></label>
                                            <div class="col-md-6">
                                            <table id="result">
                                              <tr>
                                               <th>ROLL NO</th>
                                               <th>NAME</th>
                                               <th>ENTER MARK</th>
                                              </tr>
                                              <tr>
                                               <td>1</td>
                                               <td>Maria Anders</td>
                                               <td><input type="text" name=""></td>
                                              </tr>
                                              <tr>
                                               <td>2</td>
                                               <td>Christina Berglund</td>
                                               <td><input type="text" name=""></td>
                                              </tr>
                                              <tr>
                                                <td></td>
                                                <td><input type="submit"  id="addque" name="addque" class="btn btn-danger" value="UPDATE"></td>
                                              </tr>
                                            </table>
                                            </div>
                                        </div> 
                                        

                                </div>

<!-- end of update -->
<!-- time table settings -->
                                  <?php
                                   include("query.php");
                                   $obj=new query();
                                  ?>
                                <div id="btn4">
                                <div class="card-header">TIMETABLE SETTINGS</div>
                                <br>
                                <div class="form-group row" >
                                            <label for="stud_sem" class="col-md-4 col-form-label text-md-right">SEMESTER</label>
                                            <div class="col-md-6">
                                            <select name="state"class="form-control"onchange="show(this.value)">
                                            <option value="">SELECT SEMESTER</option>
                                            <?php
                                             $res=$obj->selectsem();
                                             while($r=mysqli_fetch_array($res))
                                               {
                                            ?>
                                             <option value="<?php echo $r[0];?>"><?php echo $r[1];?></option>
                                             <?php
                                               }
                                              ?>
                                            </select>
                                            </div>
                                        </div>  
                                        
                                        <div class="form-group row">
                                            <label for="stud_sem" class="col-md-1 col-form-label text-md-right"></label>
                                            <div class="col-md-10">
                                            <div id="txtHint" ></div>
                                            </div>
                                        </div> 
                                        
                                </div>
<!-- end of time table settings -->

                                <div id="btn5">
                                <div class="card-header">NOTIFICATIONS</div>
                                                  <!--notification -->
                                                  <table class="table table-striped">
  <thead>
    <tr>
      <th scope="col">SL.NO</th>
      <th scope="col">DATE</th>
      <th scope="col">NOTIFICATION</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">1</th>
      <td>01/01/2020</td>
      <td>S3 Result Published</td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>02/01/2022</td>
      <td>Time Table of S2 Internal Exam Published</td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>09/07/2021</td>
      <td>There Will be online classes tomorrow</td>
    </tr>
  </tbody>
</table>

                                </div>
                                <!-- end of notifications -->
                                <!-- ADD QUESTIONS -->
                                
                                <div id = "addqus" >
                                <div class="card-header">ADD QUESTIONS</div>
                                <br>
                                <form action="add_question_process.php" method="post">
                                <div class="form-group row" >
                                            <label for="ques_sem" class="col-md-4 col-form-label text-md-right">SEMESTER</label>
                                            <div class="col-md-6">
                                            <select name="ques_sem" id="ques_sem" class="form-control">
                                              <option value="S1">S1</option>
                                              <option value="S2">S2</option>
                                              <option value="S3">S3</option>
                                              <option value="S4">S4</option>
                                              <option value="S5">S5</option>
                                              <option value="S6">S6</option>
                                            </select>
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label for="ques_sub" class="col-md-4 col-form-label text-md-right">SUBJECT</label>
                                            <div class="col-md-6">
                                            <select name="ques_sub" id="ques_sub" class="form-control">
                                              <option value="Mathematical Foundations to Computing">MATHEMATICAL FOUNDATIONS OF COMPUTING</option>
                                              <option value="Digital Fundamentals of Computer Architecture">DIGITAL FUNDAMENTALS OF COMPUTER ARCHITECTURE</option>
                                              <option value="ads">ADVANCED DATA STRUCTURES</option>
                                              <option value="se">SOFTWARE ENGINEERING</option>
                                              <option value="wp">WEB PROGRAMMING</option>
                                              <option value="py">PYTHON LAB</option>
                                            </select>
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label for="ques_type" class="col-md-4 text-md-right">QUESTION TYPE</label>
                                                <div class="col-md-6">
                                                    SHORT QUESTION&nbsp;&nbsp;<input type="radio" id="rd1" name="ques_type" value="short">
                                                    ESSAY QUESTION&nbsp;&nbsp;<input type="radio" id="rd2" name="ques_type" value="essay">
                                                </div>
                                        </div>

                                        <div class="form-group row">
                                            <label for="ques_question" class="col-md-4 col-form-label text-md-right">QUESTION</label>
                                            <div class="col-md-6">
                                                <textarea name="ques_question" class="form-control"></textarea>
                                            </div>
                                        </div>
                                        
                                        <div class="form-group row">
                                            <label for="stud_mod" class="col-md-4 text-md-right">MODULE</label>
                                                <div class="col-md-6">
                                                <select name="module" id="module" class="form-control">
                                              <option value="">1</option>
                                              <option value="2">2</option>
                                              <option value="3">3</option>
                                              <option value="4">4</option>
                                              <option value="5">5</option>
                                            </select>
                                            
                                                </div>
                                        </div>

                                        <div class="form-group row">
                                            <label for="ques_klevel" class="col-md-4 col-form-label text-md-right">K Level</label>
                                            <div class="col-md-6">
                                                <input type="text" name="ques_klevel" class="form-control">
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label for="ques_coklevel" class="col-md-4 col-form-label text-md-right">CO & K Level</label>
                                            <div class="col-md-6">
                                                <input type="text" name="ques_coklevel" class="form-control">
                                            </div>
                                        </div>


                                        <div class="form-group row">
                                            <label for="ques_remarks" class="col-md-4 col-form-label text-md-right">REMARKS</label>
                                            <div class="col-md-6">
                                                <input type="text" id="ques_remarks" class="form-control" name="ques_remarks" >
                                            </div>
                                        </div>

                                        <div class="col-md-6 offset-md-4">
                                            <input type="submit" class="btn btn-primary" value="SUBMIT">
                                        </div>

                                        </form>
                                    </div>
                                   </div>
                                  
                                <!-- END OF ADD QUESTIONS -->

                                <!-- GENERATE QUESTION PAPER -->
                                 
                                <div id = "ques" >
                                <div class="card-header">GENERATE QUESTION PAPER</div>
                                <br>
                                <form method="post" action="sample.php"> 
                                <div class="form-group row" >
                                            <label for="genqp_sem" class="col-md-4 col-form-label text-md-right">SEMESTER</label>
                                            <div class="col-md-6">
                                            <select name="genqp_sem" id="student_sem" class="form-control">
                                              <option value="S1">S1</option>
                                              <option value="S2">S2</option>
                                              <option value="S3">S3</option>
                                              <option value="S4">S4</option>
                                              <option value="S5">S5</option>
                                              <option value="S6">S6</option>
                                            </select>
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                            <label for="stud_gender" class="">FROM MODULE</label>
                                                <div class="col-md-2">
                                                <select name="from_mod" id="short" class="form-control">
                                              <option value="">1</option>
                                              <option value="2">2</option>
                                              <option value="3">3</option>
                                              <option value="4">4</option>
                                              <option value="5">5</option>
                                            </select>
                                            
                                                </div>
                                                <label for="stud_gender" class="">TO MODULE</label>
                                                <div class="col-md-2">
                                                <select name="to_mod" id="short" class="form-control">
                                              <option value="1">1</option>
                                              <option value="2">2</option>
                                              <option value="3">3</option>
                                              <option value="4">4</option>
                                              <option value="5">5</option>
                                            </select>
                                            
                                                </div>
                                        </div>

                                        <div class="form-group row">
                                            <label for="stud_gender" class="col-md-4 text-md-right">TOTAL SHORT QUESTIONS</label>
                                                <div class="col-md-6">
                                                <select name="short" id="short" class="form-control">
                                              <option value="5">5</option>
                                              <option value="10">10</option>
                                              <option value="15">15</option>
                                            </select>
                                            
                                                </div>
                                        </div>

                                        <div class="form-group row">
                                            <label for="genqp_sub" class="col-md-4 col-form-label text-md-right">SUBJECT</label>
                                            <div class="col-md-6">
                                            <select name="genqp_sub" id="genqp_sub" class="form-control">
                                              <option value="Mathematical Foundations to Computing">MATHEMATICAL FOUNDATIONS OF COMPUTING</option>
                                              <option value="dfc">DIGITAL FUNDAMENTALS OF COMPUTER ARCHITECTURE</option>
                                              <option value="S3">ADVANCED DATA STRUCTURES</option>
                                              <option value="S4">SOFTWARE ENGINEERING</option>
                                              <option value="S5">WEB PROGRAMMING</option>
                                              <option value="S6">PYTHON LAB</option>
                                            </select>
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label for="stud_gender" class="col-md-4 text-md-right">TOTAL SHORT QUESTIONS</label>
                                                <div class="col-md-6">
                                                <select name="short" id="short" class="form-control">
                                              <option value="5">5</option>
                                              <option value="10">10</option>
                                              <option value="15">15</option>
                                            </select>
                                            
                                                </div>
                                        </div>

                                        <div class="form-group row">
                                            <label for="stud_address" class="col-md-4 col-form-label text-md-right">TOTAL ESSAY QUESTION</label>
                                            <div class="col-md-6">
                                            <select name="essay" id="student_sem" class="form-control">
                                              <option value="5">5</option>
                                              <option value="10">10</option>
                                              <option value="15">15</option>
                                            </select>
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label for="stud_address" class="col-md-4 col-form-label text-md-right">DESCRIPTION</label>
                                            <div class="col-md-6">
                                                <textarea name="student_address" class="form-control"></textarea>
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label for="stud_mobile" class="col-md-4 col-form-label text-md-right">EXAM TYPE</label>
                                            <div class="col-md-6">
                                            <select name="student_sem" id="student_sem" class="form-control">
                                              <option value="IAE1">IAE1</option>
                                              <option value="IAE2">IAE2</option>
                                              <option value="OTHERS">OTHERS</option>
                                            </select>
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-6 offset-md-4">
                                         
                          <input type="submit" name="create_pdf" class="btn btn-danger" value="Create PDF" />  
                     </form>
                                        </div>

                                      
                                    </div>
                                   </div>
                                   
                                   <!-- END OF GENERATE QUESTION PAPER -->
                </div>
            </div>
        </div>
    </div>
    </div>

</main>



<script>
    const text = function() {
    document.querySelector("#addqus").style.display = "none";
    document.querySelector("#ques").style.display = "none";
    document.querySelector("#ques").style.display = "none";
    document.querySelector("#btn2").style.display = "none";
    document.querySelector("#btn3").style.display = "none";
    document.querySelector("#btn4").style.display = "none";
    document.querySelector("#btn5").style.display = "none";

     document.querySelector("#rd1").addEventListener('click', function () {
         document.querySelector("#btn1").style.display = "block";
         document.querySelector("#btn3").style.display = "none";
         document.querySelector("#btn2").style.display = "none";
         document.querySelector("#btn4").style.display = "none";
         document.querySelector("#btn5").style.display = "none";
         document.querySelector("#addqus").style.display = "none";
         document.querySelector("#ques").style.display = "none";
     });
     document.querySelector("#rd2").addEventListener('click', function () {
        document.querySelector("#btn1").style.display = "none";
        document.querySelector("#btn3").style.display = "none";
        document.querySelector("#btn2").style.display = "block";
        document.querySelector("#btn4").style.display = "none";
        document.querySelector("#btn5").style.display = "none";
        document.querySelector("#addqus").style.display = "none";
        document.querySelector("#ques").style.display = "none";
     });
     document.querySelector("#rd3").addEventListener('click', function () {
        document.querySelector("#btn1").style.display = "none";
        document.querySelector("#btn2").style.display = "none";
        document.querySelector("#btn3").style.display = "block";
        document.querySelector("#btn4").style.display = "none";
        document.querySelector("#btn5").style.display = "none";
        document.querySelector("#addqus").style.display = "none";
        document.querySelector("#ques").style.display = "none";
     });
     document.querySelector("#rd4").addEventListener('click', function () {
        document.querySelector("#btn1").style.display = "none";
        document.querySelector("#btn2").style.display = "none";
        document.querySelector("#btn3").style.display = "none";
        document.querySelector("#btn4").style.display = "block";
        document.querySelector("#btn5").style.display = "none";
        document.querySelector("#addqus").style.display = "none";
        document.querySelector("#ques").style.display = "none";
     });
     document.querySelector("#rd5").addEventListener('click', function () {
        document.querySelector("#btn1").style.display = "none";
        document.querySelector("#btn2").style.display = "none";
        document.querySelector("#btn3").style.display = "none";
        document.querySelector("#btn4").style.display = "none";
        document.querySelector("#btn5").style.display = "block";
        document.querySelector("#addqus").style.display = "none";
        document.querySelector("#ques").style.display = "none";
     });
     document.querySelector("#addque").addEventListener('click', function () {
        document.querySelector("#btn1").style.display = "none";
        document.querySelector("#btn2").style.display = "block";
        document.querySelector("#btn3").style.display = "none";
        document.querySelector("#btn4").style.display = "none";
        document.querySelector("#btn5").style.display = "none";
        document.querySelector("#ques").style.display = "none";
        document.querySelector("#addqus").style.display = "block";
     });
     document.querySelector("#qp").addEventListener('click', function () {
        document.querySelector("#btn1").style.display = "none";
        document.querySelector("#btn2").style.display = "block";
        document.querySelector("#btn3").style.display = "none";
        document.querySelector("#btn4").style.display = "none";
        document.querySelector("#btn5").style.display = "none";
        document.querySelector("#addqus").style.display = "none";
        document.querySelector("#ques").style.display = "block";
     });
 }

 text();
</script>

<script type="text/javascript">
function show(str)
{
if (str=="")
  {
  document.getElementById("txtHint").innerHTML="";
  return;
  } 
if (window.XMLHttpRequest)
  {// code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  }
else
  {// code for IE6, IE5
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
xmlhttp.onreadystatechange=function()
  {
 
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
   
    document.getElementById("txtHint").innerHTML=xmlhttp.responseText;
    }
  }
xmlhttp.open("GET","selectsubject.php?cid="+str,true);

xmlhttp.send();
}
</script>


</body>
</html>