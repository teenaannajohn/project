<?php
include("query.php");
$ques_sem=$_POST["ques_sem"];
$ques_sub=$_POST["ques_sub"];
$ques_type=$_POST["ques_type"];
$ques_question=$_POST["ques_question"];
$ques_remarks=$_POST["ques_remarks"];
$ques_klevel=$_POST["ques_klevel"];
$ques_coklevel=$_POST["ques_coklevel"];
$module=$_POST["module"];

$ob= new query();
$res=$ob->add_ques($ques_sem,$ques_sub,$ques_type,$ques_question,$ques_remarks,$ques_klevel,$ques_coklevel,$module);
if($res>0)
{
    header("location:sample.php?msg=2");
 }
 else
 {
     header("location:sample.php?msg=0");  
 }
?>