<?php
session_start();

$username=$_POST["username"];
$password=$_POST["password"];
$con=mysqli_connect("localhost","root","","exam","4306");
$sql="select * from login where lgn_username='$username' and lgn_pwd='$password'";
$result=mysqli_query($con,$sql);
if(mysqli_num_rows($result)==1)
{
	$row=mysqli_fetch_array($result);
	
	
	
	$_SESSION["username"]=$username;
	$_SESSION["lid"]=$row[0];
	
	
	
	if($row[3]=="teacher")
	{
		header("location:teacher_home.php");
	}
	else if($row[3]=="student")
	{
		header("location:student_home.php");
	}
    else if($row[3]=="admin")
	{
		header("location:admin_home.php");
	}
}
	else
	{
		echo "Permission Denied";
	}
	
?>