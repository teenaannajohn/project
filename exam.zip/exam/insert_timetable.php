<?php
include("query.php");
$tt_sem=$_POST["tt_sem"];
$tt_subject=$_POST["tt_subject"];
$tt_date=$_POST["tt_date"];
$tt_from=$_POST["tt_from"];
$tt_to=$_POST["tt_to"];
$tt_invigilator=$_POST["tt_invigilator"];
$tt_room=$_POST["tt_room"];

$ob= new query();
$res=$ob->tt_insert($tt_sem,$tt_subject,$tt_date,$tt_from,$tt_to,$tt_invigilator,$tt_room);
 if($res>0)
{
     header("location:teacher_home.php?msg=0");
}
 else
 {
     header("location:teacher_home.php?msg=1");  
 }
?>