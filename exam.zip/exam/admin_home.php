<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<link href="login_css.css" rel="stylesheet" id="login-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Fonts -->
    <link rel="dns-prefetch" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Raleway:300,400,600" rel="stylesheet" type="text/css">

    <link rel="stylesheet" href="css/style.css">

    <link rel="icon" href="Favicon.png">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">

    <title>EMS</title>

</head>
<body>

<nav class="navbar navbar-expand-lg navbar-light navbar-laravel">
    <div class="container">
    <img src="images/icon.png" width="80px">
        <a class="navbar-brand" href="#">AEMS</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                <input type="submit" id="rd1" class="btn btn-primary" value="MY HOME">
                </li>&nbsp;&nbsp;&nbsp;&nbsp;
                 <li class="nav-item">
                 <input type="submit" id="rd2" class="btn btn-primary" value="APPROVE TIMETABLE">
                </li> 
                &nbsp;&nbsp;&nbsp;&nbsp;
                 <li class="nav-item">
                 <input type="submit" id="rd3" class="btn btn-primary" value="ADD NOTIFICATION">
                </li>
                &nbsp;&nbsp;&nbsp;&nbsp;
                 <li class="nav-item">
                 <input type="submit" id="rd4" class="btn btn-primary" value="PUBLISH RESULTS">
                </li> 
                &nbsp;&nbsp;&nbsp;&nbsp;
                 <li class="nav-item">
                 <input type="submit" id="rd5" class="btn btn-primary" value="APPROVE REGISTRATIONS">
                </li>  
            </ul>

        </div>
    </div>
</nav>
<main class="login-form">
    <div class="cotainer" id="#reg">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
    
                <div id="btn1">
                        <div class="card-header">MY HOME</div> 
                                <H2 style=" text-align: center;">WELCOME ADMIN</H2>
                                <br>
                                <img src="images/adminhome.jpg" style="width: 100%;">
                                </div>
    
    
                                <div id="btn2">
                                <div class="card-header">APPROVE TIMETABLE</div>
                                <p>TIMETABLE</p>                  
                                </div>

                                <div id="btn3">
                                <div class="card-header">ADD NOTIFICATION</div>
                                <p>NOTIFICATION</p>                  
                                </div>

                                <div id="btn4">
                                <div class="card-header">RESULTS</div>
                                <p>RESULTS</p>                  
                                </div>

                                <div id="btn5">
                                <div class="card-header">APPROVE REGISTRATIONS</div>
                                <div id = "add">
                                <div class="col-md-9 offset-md-4">
                                <input type="submit"  id="newreg" name="newreg" class="btn btn-warning" value="NEW REGISTRATIONS">
                                <input type="submit"  id="approved_usrs" name="approved_usrs" class="btn btn-warning" value="APPROVED USERS">                  
                                </div>
                            </div>
                        </div>
<!-- pending approvals -->
<?php
include("query.php");
$obj=new query();
$res=$obj->pending_approvals();
?>
                        <div id="pending_approvals">
                                <div class="card-header">PENDING APPROVALS</div>
                                <label for="stud_sem" class="col-md-1 col-form-label text-md-right"></label>
                                            <div class="col-md-10">
                                                <form method="post" action="insert_timetable.php">
                                                    
                                            <table id="timetable">
                                              <tr>
                                               <th>SUBJECTS</th>
                                               <th>DATE</th>
                                               <th>FROM</th>
                                               <th>TO</th>
                                               <th>INVIGILATOR</th>
                                               <th>ROOM NO</th>
                                              </tr>
                                              <?php
                                              while($r=mysqli_fetch_array($res))
                                              {
                                              ?>
                                              
                                              <tr>
                                               <td ><?php echo $r[1];?></td>
                                               <td><input type="date" id="tt_date" class="form-control" name="tt_date" ></td>
                                               <td><select name="tt_from" id="tt_from" class="form-control">
                                              <option value="9">9</option>
                                              <option value="10">10</option>
                                              <option value="11">11</option>
                                              <option value="1">1</option>
                                              <option value="2">2</option>
                                              <option value="3">3</option>
                                            </select></td>
                                               <td><select name="tt_to" id="tt_to" class="form-control">
                                              <option value="9">9</option>
                                              <option value="10">10</option>
                                              <option value="11">11</option>
                                              <option value="1">1</option>
                                              <option value="2">2</option>
                                              <option value="3">3</option>
                                            </select></td>
                                               <td><select name="tt_invigilator" id="tt_invigilator" class="form-control">
                                              <option value="invi1">invigilator1</option>
                                              <option value="invi2">invigilator2</option>
                                              <option value="invi3">invigilator3</option>
                                              <option value="invi4">invigilator4</option>
                                              <option value="invi5">invigilator5</option>
                                              <option value="invi6">invigilator6</option>
                                            </select></td>
                                               <td><select name="tt_room" id="tt_room" class="form-control">
                                              <option value="100">100</option>
                                              <option value="101">101</option>
                                              <option value="102">102</option>
                                              <option value="103">103</option>
                                              <option value="104">104</option>
                                              <option value="105">105</option>
                                            </select></td>
                                              </tr>
                                              <?php
                                            }
                                            ?>
                                            <tr>
                                                <td colspan="6"><input type="submit" class="btn btn-danger" value="SUBMIT"></td>
                                            </tr>
                                              
                                            </table>
                                        </form>                  
                                </div>
                                <!-- end of pending approvals -->

                                <!-- Approved Users -->
                                <div id="approved_users">
                                <div class="card-header">APPROVED USERS</div>
                                <p>approved results</p>                  
                                </div>
                                <!-- End of approved users -->
                </div>
            </div>
        </div>
    </div>
    </div>

</main>



<script>
    const text = function() {
    document.querySelector("#btn2").style.display = "none";
    document.querySelector("#btn3").style.display = "none";
    document.querySelector("#btn4").style.display = "none";
    document.querySelector("#btn5").style.display = "none";
    document.querySelector("#pending_approvals").style.display = "none";
    document.querySelector("#approved_users").style.display = "none";
    
    

     document.querySelector("#rd1").addEventListener('click', function () {
         document.querySelector("#btn1").style.display = "block";
         document.querySelector("#btn3").style.display = "none";
         document.querySelector("#btn2").style.display = "none";
         document.querySelector("#btn4").style.display = "none";
         document.querySelector("#btn5").style.display = "none";
         document.querySelector("#pending_approvals").style.display = "none";
         document.querySelector("#approved_users").style.display = "none";
     });
     document.querySelector("#rd2").addEventListener('click', function () {
        document.querySelector("#btn1").style.display = "none";
        document.querySelector("#btn3").style.display = "none";
        document.querySelector("#btn2").style.display = "block";
        document.querySelector("#btn4").style.display = "none";
        document.querySelector("#btn5").style.display = "none";
        document.querySelector("#pending_approvals").style.display = "none";
        document.querySelector("#approved_users").style.display = "none";
     });
     document.querySelector("#rd3").addEventListener('click', function () {
        document.querySelector("#btn1").style.display = "none";
        document.querySelector("#btn2").style.display = "none";
        document.querySelector("#btn3").style.display = "block";
        document.querySelector("#btn4").style.display = "none";
        document.querySelector("#btn5").style.display = "none";
        document.querySelector("#pending_approvals").style.display = "none";
        document.querySelector("#approved_users").style.display = "none";
     });
     document.querySelector("#rd4").addEventListener('click', function () {
        document.querySelector("#btn1").style.display = "none";
        document.querySelector("#btn2").style.display = "none";
        document.querySelector("#btn3").style.display = "none";
        document.querySelector("#btn4").style.display = "block";
        document.querySelector("#btn5").style.display = "none";
        document.querySelector("#pending_approvals").style.display = "none";
        document.querySelector("#approved_users").style.display = "none";
     });
     document.querySelector("#rd5").addEventListener('click', function () {
        document.querySelector("#btn1").style.display = "none";
        document.querySelector("#btn2").style.display = "none";
        document.querySelector("#btn3").style.display = "none";
        document.querySelector("#btn4").style.display = "none";
        document.querySelector("#btn5").style.display = "block";
        document.querySelector("#pending_approvals").style.display = "none";
        document.querySelector("#approved_users").style.display = "none";
     });
     document.querySelector("#newreg").addEventListener('click', function () {
        document.querySelector("#btn1").style.display = "none";
        document.querySelector("#btn2").style.display = "none";
        document.querySelector("#btn3").style.display = "none";
        document.querySelector("#btn4").style.display = "none";
        document.querySelector("#btn5").style.display = "block";
        document.querySelector("#pending_approvals").style.display = "block";
        document.querySelector("#approved_users").style.display = "none";
     });
     document.querySelector("#approved_usrs").addEventListener('click', function () {
        document.querySelector("#btn1").style.display = "none";
        document.querySelector("#btn2").style.display = "none";
        document.querySelector("#btn3").style.display = "none";
        document.querySelector("#btn4").style.display = "none";
        document.querySelector("#btn5").style.display = "block";
        document.querySelector("#pending_approvals").style.display = "none";
        document.querySelector("#approved_users").style.display = "block";
     });
 }

text();
</script>



</body>
</html>