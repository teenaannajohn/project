<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<link href="teacher_home_css.css" rel="stylesheet">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
	<?php
	$cid=$_GET["cid"];
	
include("query.php");
$obj=new query();
$res=$obj->selectsub($cid);
?>
	<div class="form-group row">
                                            <label for="stud_sem" class="col-md-1 col-form-label text-md-right"></label>
                                            <div class="col-md-10">
                                            <table id="timetable">
                                              <tr>
                                               <th>SUBJECTS</th>
                                               <th>DATE</th>
                                               <th>FROM</th>
                                               <th>TO</th>
                                               <th>INVIGILATOR</th>
                                               <th>ROOM NO</th>
                                              </tr>
                                              <?php
                                              while($r=mysqli_fetch_array($res))
{
?>
                                              <tr>
                                               <td ><?php echo $r[1];?></td>
                                               <td><input type="date" id="stud_dob" class="form-control" name="stud_dob" ></td>
                                               <td><select name="student_sem" id="student_sem" class="form-control">
                                              <option value="5">5</option>
                                              <option value="10">10</option>
                                              <option value="15">15</option>
                                            </select></td>
                                               <td><select name="student_sem" id="student_sem" class="form-control">
                                              <option value="5">5</option>
                                              <option value="10">10</option>
                                              <option value="15">15</option>
                                            </select></td>
                                               <td><select name="student_sem" id="student_sem" class="form-control">
                                              <option value="S1">invi1</option>
                                              <option value="S2">invi2</option>
                                              <option value="S3">invi3</option>
                                              <option value="S4">S4</option>
                                              <option value="S5">S5</option>
                                              <option value="S6">S6</option>
                                            </select></td>
                                               <td><select name="student_sem" id="student_sem" class="form-control">
                                              <option value="5">5</option>
                                              <option value="10">10</option>
                                              <option value="15">15</option>
                                            </select></td>
                                              </tr>
                                              <?php
                                            }
                                            ?>
                                            <tr>
                                            	<td colspan="6"><input type="submit" id="rd1" class="btn btn-primary" value="SUBMIT"></td>
                                            </tr>
                                              
                                            </table>
                                            </div>

 <!-- <select name="city" id="select" class="form-control">
  <option selected="selected">SELECT YOUR CITY</option>
<?php
// 	$cid=$_GET["cid"];
	
// include("query.php");
// $obj=new query();
// $res=$obj->selectsub($cid);
// while($r=mysqli_fetch_array($res))
{
?>

 
    <!-- <option value="<?php //echo $r[0];?>"><?php //echo $r[2];?></option> -->
   <!--  <?php
}
	?> -->
 <!--  </select> -->
 <!-- <input type="text" name="textfield" id="textfield" value="<?php //echo $r[1];?>" />-->

</body>
</html>