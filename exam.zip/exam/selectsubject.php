<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<link href="teacher_home_css.css" rel="stylesheet">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
	<?php
	$cid=$_GET["cid"];
	
include("query.php");
$obj=new query();
$res=$obj->selectsub($cid);
?>
	<div class="form-group row">
                                            <label for="stud_sem" class="col-md-1 col-form-label text-md-right"></label>
                                            <div class="col-md-10">
                                            	<form method="post" action="insert_timetable.php">
                                            		
                                            <table id="timetable">
                                              <tr>
                                               <th>SUBJECTS</th>
                                               <th>DATE</th>
                                               <th>FROM</th>
                                               <th>TO</th>
                                               <th>INVIGILATOR</th>
                                               <th>ROOM NO</th>
                                              </tr>
                                              <?php
                                              while($r=mysqli_fetch_array($res))
                                              {
                                              ?>
                                              <input type="hidden" name="tt_sem" value="<?php echo $cid;?>">
                                              <input type="hidden" name="tt_subject" value="<?php echo $r[0];?>">
                                              <tr>
                                               <td ><?php echo $r[1];?></td>
                                               <td><input type="date" id="tt_date" class="form-control" name="tt_date" ></td>
                                               <td><select name="tt_from" id="tt_from" class="form-control">
                                              <option value="9">9</option>
                                              <option value="10">10</option>
                                              <option value="11">11</option>
                                              <option value="1">1</option>
                                              <option value="2">2</option>
                                              <option value="3">3</option>
                                            </select></td>
                                               <td><select name="tt_to" id="tt_to" class="form-control">
                                              <option value="9">9</option>
                                              <option value="10">10</option>
                                              <option value="11">11</option>
                                              <option value="1">1</option>
                                              <option value="2">2</option>
                                              <option value="3">3</option>
                                            </select></td>
                                               <td><select name="tt_invigilator" id="tt_invigilator" class="form-control">
                                              <option value="invi1">invigilator1</option>
                                              <option value="invi2">invigilator2</option>
                                              <option value="invi3">invigilator3</option>
                                              <option value="invi4">invigilator4</option>
                                              <option value="invi5">invigilator5</option>
                                              <option value="invi6">invigilator6</option>
                                            </select></td>
                                               <td><select name="tt_room" id="tt_room" class="form-control">
                                              <option value="100">100</option>
                                              <option value="101">101</option>
                                              <option value="102">102</option>
                                              <option value="103">103</option>
                                              <option value="104">104</option>
                                              <option value="105">105</option>
                                            </select></td>
                                              </tr>
                                              <?php
                                            }
                                            ?>
                                            <tr>
                                            	<td colspan="6"><input type="submit" class="btn btn-danger" value="SUBMIT"></td>
                                            </tr>
                                              
                                            </table>
                                        </form>
                                            </div>

 <!-- <select name="city" id="select" class="form-control">
  <option selected="selected">SELECT YOUR CITY</option>
<?php
// 	$cid=$_GET["cid"];
	
// include("query.php");
// $obj=new query();
// $res=$obj->selectsub($cid);
// while($r=mysqli_fetch_array($res))
{
?>

 
    <!-- <option value="<?php //echo $r[0];?>"><?php //echo $r[2];?></option> -->
   <!--  <?php
}
	?> -->
 <!--  </select> -->
 <!-- <input type="text" name="textfield" id="textfield" value="<?php //echo $r[1];?>" />-->

</body>
</html>