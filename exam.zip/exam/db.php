<?php
    $servername='localhost';
    $username='root';
    $password='';
    $dbname = "exam";
    $conn=mysqli_connect($servername,$username,$password,"$dbname","4306");
      if(!$conn){
          die('Could not Connect MySql Server:' .mysql_error());
        }
?>