<!DOCTYPE html>
<html>
<style>
img.center {
    
    
}
h2,h4,h5{
    
}
</style>
<body>
    <table border="0">

<tr><img src="images/clg_logo.jpg" style="display: block;margin: 0 auto;"></tr>
<tr><h2 style="text-align:center">DEPARTMENT OF MCA</h2></tr>
<tr><h4 style="text-align:center">First Internal Assessment Examination-DEC 2021</h4></tr>
<tr><h5 style="text-align:center">First Semester MCA</h5></tr>
<tr><h5 style="text-align:center">20MCA278-ADVANCED DATA STRUCTURES</h5></tr>
<tr><h4 style="text-align:center">PART A(3*10=30)&nbsp;&nbsp;&nbsp;ANSWER ALL QUESTIONS</h4>
</table>
<table border="1">
  <tr>
    <th>Q.No</th>
    <th style="width:400px">Questions</th>
    <th>Marks</th>
    <th>K Level</th>
    <th>CO & K Level </th>
  </tr>
  <tr>
    <td>1.</td>
    <td>Write note on bioinformatics</td>
    <td>3</td>
    <td>K1</td>
    <td>CO1(K2)</td>
  </tr>
  <tr>
    <td>2.</td>
    <td>Write a short note on "how genome carries hereditary data from organisms"</td>
    <td>3</td>
    <td>K2</td>
    <td>CO1(K2)</td>
  </tr>
  <tr>
    <td>1.</td>
    <td>Write note on bioinformatics</td>
    <td>3</td>
    <td>K1</td>
    <td>CO1(K2)</td>
  </tr>
  <tr>
    <td>2.</td>
    <td>Write a short note on "how genome carries hereditary data from organisms"</td>
    <td>3</td>
    <td>K2</td>
    <td>CO1(K2)</td>
  </tr>
  <tr>
    <td>2.</td>
    <td>Write a short note on "how genome carries hereditary data from organisms"</td>
    <td>3</td>
    <td>K2</td>
    <td>CO1(K2)</td>
  </tr>
  <tr>
    <td>2.</td>
    <td>Write a short note on "how genome carries hereditary data from organisms"</td>
    <td>3</td>
    <td>K2</td>
    <td>CO1(K2)</td>
  </tr>
  <tr>
    <td>2.</td>
    <td>Write a short note on "how genome carries hereditary data from organisms"</td>
    <td>3</td>
    <td>K2</td>
    <td>CO1(K2)</td>
  </tr>
  <tr>
    <td>2.</td>
    <td>Write a short note on "how genome carries hereditary data from organisms"</td>
    <td>3</td>
    <td>K2</td>
    <td>CO1(K2)</td>
  </tr>
  <tr>
    <td>2.</td>
    <td>Write a short note on "how genome carries hereditary data from organisms"</td>
    <td>3</td>
    <td>K2</td>
    <td>CO1(K2)</td>
  </tr>
</table>
<h4 style="text-align:center">PART B(10*2=20)&nbsp;&nbsp;&nbsp;ANSWER ANY 2 QUESTIONS</h4>
<table style="margin: 0px auto;width:50%" border="1">
  <tr>
    <th>Q.No</th>
    <th style="width:400px">Questions</th>
    <th>Marks</th>
    <th>K Level</th>
    <th>CO & K Level </th>
  </tr>
  <tr>
    <td>11.</td>
    <td>What is central dogma of molecular biology?How can Molecular biology be considered as an information science?</td>
    <td>3</td>
    <td>K1</td>
    <td>CO1(K2)</td>
  </tr>
  <tr>
    <td>2.</td>
    <td>Write a short note on "how genome carries hereditary data from organisms"</td>
    <td>3</td>
    <td>K2</td>
    <td>CO1(K2)</td>
  </tr>
  <tr>
    <td>1.</td>
    <td>Write note on bioinformatics</td>
    <td>3</td>
    <td>K1</td>
    <td>CO1(K2)</td>
  </tr>
  <tr>
    <td>2.</td>
    <td>Write a short note on "how genome carries hereditary data from organisms"</td>
    <td>3</td>
    <td>K2</td>
    <td>CO1(K2)</td>
  </tr>
  
</table>
</body>
</html>

