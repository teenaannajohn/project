<?php
include("query.php");
$student_admission_no=$_POST["student_admission_no"];
$student_fname=$_POST["student_fname"];
$student_lname=$_POST["student_lname"];
$student_gender=$_POST["stud_gender"];
$student_dob=$_POST["stud_dob"];
$student_mobile=$_POST["student_mobile"];
$student_address=$_POST["student_address"];
$student_sem=$_POST["student_sem"];
$student_email=$_POST["student_email"];
$student_rollno=$_POST["student_rollno"];
$student_username=$_POST["student_username"];
$student_password=$_POST["student_password"];
$id=0;

$ob= new query();
$res=$ob->stud_reg($student_admission_no,$student_fname,$student_lname,$student_gender,$student_dob,$student_mobile,
$student_address,$student_sem,$student_email,$student_rollno,$student_username,$student_password,$id);
if($res>0)
{
    header("location:index.php?msg=0");
 }
 else
 {
     header("location:index.php?msg=1");  
 }
?>