<?php
include("connection.php");
class query
{
    function stud_reg($student_admission_no,$student_fname,$student_lname,$student_gender,$student_dob,$student_mobile,
    $student_address,$student_sem,$student_email,$student_rollno,$student_username,$student_password,$id)
    {
        $ob=new connection();
        echo $q="insert into login(lgn_username,lgn_pwd,lgn_role,lgn_status)values('$student_username','$student_password','student',0)";
        $r=$ob->execute($q);
        echo $id=mysqli_insert_id($ob->con);
        echo $qry="insert into tbl_student_reg(stud_admission_no,stud_fname,stud_lname,stud_gender,stud_dob,stud_mobile,
        stud_address,stud_sem,stud_email,stud_rollno,stud_lid)values('$student_admission_no','$student_fname','$student_lname','$student_gender'
        ,'$student_dob','$student_mobile','$student_address','$student_sem','$student_email','$student_rollno',$id)";
        $res=$ob->execute($qry);
        return $res;
    }
    function teacher_reg($teacher_empid,$teacher_fname,$teacher_lname,$teacher_dob,$teacher_gender,$teacher_address,
    $teacher_email,$teacher_mobile,$teacher_username,$teacher_password,$id)
    {
        $ob=new connection();
        $q="insert into login(lgn_username,lgn_pwd,lgn_role,lgn_status)values('$teacher_username','$teacher_password','teacher',0)";
        $r=$ob->execute($q);
        $id=mysqli_insert_id($ob->con);
        $qry="insert into tbl_teacher_reg(teacher_empid,teacher_fname,teacher_lname,teacher_dob,teacher_gender,teacher_address,
        teacher_email,teacher_mobile,teacher_lid)values('$teacher_empid','$teacher_fname','$teacher_lname','$teacher_dob','$teacher_gender','$teacher_address',
        '$teacher_email','$teacher_mobile',$id)";
        $res=$ob->execute($qry);
        return $res;
    }
    function add_ques($ques_sem,$ques_sub,$ques_type,$ques_question,$ques_remarks,$ques_klevel,$ques_coklevel,$module)
    {
        $ob=new connection();
        echo $qry="insert into question_paper(q_sem,q_subject,q_qtype,q_question,q_remarks,q_klevel,q_coklevel,module)values
        ('$ques_sem','$ques_sub','$ques_type','$ques_question','$ques_remarks','$ques_klevel','$ques_coklevel',$module)";
        $res=$ob->execute($qry);
        return $res;
    }
    function selectsem()
    {
        $ob=new connection();
        echo $qry="select * from semester";
        $res=$ob->execute($qry);
        return $res;
    }
    function selectsub($cid)
    {
        $ob=new connection();
        $qry="select * from subjects where sem='$cid'";
        $res=$ob->execute($qry);
        return $res;
    }
    function tt_insert($tt_sem,$tt_subject,$tt_date,$tt_from,$tt_to,$tt_invigilator,$tt_room)
    {
        $ob=new connection();
        $qry="insert into tbl_timetable(tt_sem,tt_subject,tt_date,tt_from,tt_to,tt_invigilator,tt_room)values
        ($tt_sem,$tt_subject,'$tt_date','$tt_from','$tt_to','$tt_invigilator',$tt_room)";
        $res=$ob->execute($qry);
        return $res;
    }
    function selectsem()
    {
        $ob=new connection();
        echo $qry="select * from semester";
        $res=$ob->execute($qry);
        return $res;
    }

}
?>