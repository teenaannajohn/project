<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Fonts -->
    <link rel="dns-prefetch" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Raleway:300,400,600" rel="stylesheet" type="text/css">

    <link rel="stylesheet" href="css/style.css">

    <link rel="icon" href="Favicon.png">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">

    <title>EMS_User Registration</title>

</head>
<body>



<nav class="navbar navbar-expand-lg navbar-light navbar-laravel">
    <div class="container">
    <img src="images/icon.png" width="80px">
        <a class="navbar-brand" href="#">AEMS</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
    </div>
</nav>

<main class="login-form">
     <div class="cotainer">
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header">REGISTRATION</div>
                             
                                        <div class="form-group row">
                                            <label for="student_or_teacher" class="col-md-4 text-md-right">Are You a Student?</label>
                                                <div class="col-md-4">
                                                    Yes&nbsp;&nbsp;<input type="radio" id="rd1" name="sort" value="yes" checked>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                                    No&nbsp;&nbsp;<input type="radio" id="rd2" name="sort" value="no">
                                                </div>
                                        </div>
                            

                                <div id="student">
                                <form action="student_reg_process.php" method="post">
                                        <div class="form-group row">
                                            <!-- <h1>student</h1> -->
                                            <label for="email_address" class="col-md-4 col-form-label text-md-right">ADMISSION NUMBER</label>
                                            <div class="col-md-6">
                                                <input type="text" id="admission_no" class="form-control" name="student_admission_no" autofocus>
                                                
                                            </div>
                                        </div>
    
                                        <div class="form-group row">
                                            <label for="password" class="col-md-4 col-form-label text-md-right">FIRST NAME</label>
                                            <div class="col-md-6">
                                                <input type="text" id="student_fname" class="form-control" name="student_fname" >
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label for="stud_lname" class="col-md-4 col-form-label text-md-right">LAST NAME</label>
                                            <div class="col-md-6">
                                                <input type="text" id="student_lname" class="form-control" name="student_lname" >
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label for="stud_gender" class="col-md-4 text-md-right">GENDER</label>
                                                <div class="col-md-4">
                                                    MALE&nbsp;&nbsp;<input type="radio" id="rd1" name="stud_gender" value="male">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                                    FEMALE&nbsp;&nbsp;<input type="radio" id="rd2" name="stud_gender" value="female">
                                                </div>
                                        </div>

                                        <div class="form-group row">
                                            <label for="stud_dob" class="col-md-4 col-form-label text-md-right">DATE OF BIRTH</label>
                                            <div class="col-md-6">
                                                <input type="date" id="stud_dob" class="form-control" name="stud_dob" >
                                            </div>
                                        </div>
                                       
                                        <div class="form-group row">
                                            <label for="stud_mobile" class="col-md-4 col-form-label text-md-right">MOBILE NUMBER</label>
                                            <div class="col-md-6">
                                                <input type="number" id="student_mobile" class="form-control" name="student_mobile" >
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label for="stud_address" class="col-md-4 col-form-label text-md-right">ADDRESS</label>
                                            <div class="col-md-6">
                                                <textarea name="student_address" class="form-control"></textarea>
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label for="stud_sem" class="col-md-4 col-form-label text-md-right">SEMESTER</label>
                                            <div class="col-md-6">
                                            <select name="student_sem" id="student_sem" class="form-control">
                                              <option value="S1">S1</option>
                                              <option value="S2">S2</option>
                                              <option value="S3">S3</option>
                                              <option value="S4">S4</option>
                                              <option value="S5">S5</option>
                                              <option value="S6">S6</option>
                                            </select>
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label for="stud_email" class="col-md-4 col-form-label text-md-right">EMAIL-ID</label>
                                            <div class="col-md-6">
                                                <input type="email" id="student_email" class="form-control" name="student_email" >
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label for="stud_rollno" class="col-md-4 col-form-label text-md-right">ROLL NUMBER</label>
                                            <div class="col-md-6">
                                                <input type="number" id="student_rollno" class="form-control" name="student_rollno" >
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label for="stud_username" class="col-md-4 col-form-label text-md-right">USERNAME</label>
                                            <div class="col-md-6">
                                                <input type="text" id="student_username" class="form-control" name="student_username" >
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label for="stud_password" class="col-md-4 col-form-label text-md-right">PASSWORD</label>
                                            <div class="col-md-6">
                                                <input type="text" id="student_password" class="form-control" name="student_password" >
                                            </div>
                                        </div>

                                        <div>
                                        <div class="col-md-6 offset-md-4">
                                            <input type="submit" class="btn btn-primary" value="SUBMIT">
                                        </div>
                                </div>
                                </form>
                                </div>
    
    
                                <div id="teacher">
                                <form action="teacher_reg_process.php" method="post">    
                                        <div class="form-group row">
                                            <!-- <h1>teacher</h1> -->
                                            <label for="teacher_empid" class="col-md-4 col-form-label text-md-right">EMPLOYEE-ID</label>
                                            <div class="col-md-6">
                                                <input type="text" id="teacher_empid" class="form-control" name="teacher_empid">
                                            </div>
                                        </div>
    
                                        <div class="form-group row">
                                            <label for="teacher_fname" class="col-md-4 col-form-label text-md-right">FIRST NAME</label>
                                            <div class="col-md-6">
                                                <input type="text" id="teacher_fname" class="form-control" name="teacher_fname">
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label for="teacher_lname" class="col-md-4 col-form-label text-md-right">LAST NAME</label>
                                            <div class="col-md-6">
                                                <input type="text" id="teacher_lname" class="form-control" name="teacher_lname">
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label for="stud_dob" class="col-md-4 col-form-label text-md-right">DATE OF BIRTH</label>
                                            <div class="col-md-6">
                                                <input type="date" id="stud_dob" class="form-control" name="teacher_dob" >
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label for="teacher_gender" class="col-md-4 text-md-right">GENDER</label>
                                                <div class="col-md-4">
                                                    MALE&nbsp;&nbsp;<input type="radio" id="rd1" name="teacher_gender" value="male">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                                    FEMALE&nbsp;&nbsp;<input type="radio" id="rd2" name="teacher_gender" value="female">
                                                </div>
                                        </div>

                                        <div class="form-group row">
                                            <label for="teacher_address" class="col-md-4 col-form-label text-md-right">ADDRESS</label>
                                            <div class="col-md-6">
                                                <textarea name="teacher_address" class="form-control"></textarea>
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label for="teacher_email" class="col-md-4 col-form-label text-md-right">EMAIL-ID</label>
                                            <div class="col-md-6">
                                                <input type="text" id="teacher_email" class="form-control" name="teacher_email">
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label for="teacher_mobile" class="col-md-4 col-form-label text-md-right">MOBILE NUMBER</label>
                                            <div class="col-md-6">
                                                <input type="number" id="teacher_mobile" class="form-control" name="teacher_mobile">
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label for="teacher_username" class="col-md-4 col-form-label text-md-right">USERNAME</label>
                                            <div class="col-md-6">
                                                <input type="text" id="teacher_username" class="form-control" name="teacher_username" >
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label for="teacher_password" class="col-md-4 col-form-label text-md-right">PASSWORD</label>
                                            <div class="col-md-6">
                                                <input type="text" id="teacher_password" class="form-control" name="teacher_password" >
                                            </div>
                                        </div>


                                        <div>
                                        <div class="col-md-6 offset-md-4">
                                            <input type="submit" class="btn btn-primary" value="SUBMIT">
                                        </div>
                                </div>
                                </form>                       
                                </div>


                                <!-- <div>
                                        <div class="col-md-6 offset-md-4">
                                            <input type="submit" class="btn btn-primary" value="Login">
                                        </div>
                                </div> -->
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</main>
<script>
    const text = function() {
    document.querySelector("#teacher").style.display = "none";

     document.querySelector("#rd1").addEventListener('click', function () {
         document.querySelector("#student").style.display = "block";
         document.querySelector("#teacher").style.display = "none";
     });
     document.querySelector("#rd2").addEventListener('click', function () {
        document.querySelector("#teacher").style.display = "block";
        document.querySelector("#student").style.display = "none";
     });
 }

text();
</script>

</body>
</html>