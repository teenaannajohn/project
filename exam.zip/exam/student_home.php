<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<link href="login_css.css" rel="stylesheet" id="login-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Fonts -->
    <link rel="dns-prefetch" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Raleway:300,400,600" rel="stylesheet" type="text/css">

    <link rel="stylesheet" href="css/style.css">

    <link rel="icon" href="Favicon.png">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">

    <title>EMS</title>

</head>
<body>

<nav class="navbar navbar-expand-lg navbar-light navbar-laravel">
    <div class="container">
    <img src="images/icon.png" width="80px">
        <a class="navbar-brand" href="#">AEMS</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                <input type="submit" id="rd1" class="btn btn-primary" value="MY HOME">
                </li>&nbsp;&nbsp;&nbsp;&nbsp;
                 <li class="nav-item">
                 <input type="submit" id="rd2" class="btn btn-primary" value="SAMPLE QUESTIONS">
                </li> 
                &nbsp;&nbsp;&nbsp;&nbsp;
                 <li class="nav-item">
                 <input type="submit" id="rd3" class="btn btn-primary" value="VIEW TIMETABLE">
                </li>
                &nbsp;&nbsp;&nbsp;&nbsp;
                 <li class="nav-item">
                 <input type="submit" id="rd4" class="btn btn-primary" value="VIEW RESULT">
                </li> 
                &nbsp;&nbsp;&nbsp;&nbsp;
                 <li class="nav-item">
                 <input type="submit" id="rd5" class="btn btn-primary" value="NOTIFICATIONS">
                </li>  
            </ul>

        </div>
    </div>
</nav>
<main class="login-form">
    <div class="cotainer" id="#reg">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">

                <div id="btn1">
                        <div class="card-header" text-align: center;>MY HOME</div>
                        <H2 style=" text-align: center;">WELCOME STUDENT</H2>
                                <div style=" text-align: center;">
                                <img src="images/studenthome.jpg" style="width: %;">
                                </div>
                                </div>
    
    
                                <div id="btn2">
                                <div class="card-header">SAMPLE QUESTIONS</div>
                                <p>QUESTIONS</p>                  
                                </div>

                                <div id="btn3">
                                <div class="card-header">TIMETABLE</div>
                                <p>TIMETABLE</p>                  
                                </div>

                                <div id="btn4">
                                <div class="card-header">RESULTS</div>
                                <p>RESULTS</p>                  
                                </div>

                                <div id="btn5">
                                <div class="card-header">NOTIFICATIONS</div>
                                <p>NOTIFICATIONS</p>                  
                                </div>
                </div>
            </div>
        </div>
    </div>
    </div>

</main>



<script>
    const text = function() {
    document.querySelector("#btn1").style.display = "block";
    document.querySelector("#btn2").style.display = "none";
    document.querySelector("#btn3").style.display = "none";
    document.querySelector("#btn4").style.display = "none";
    document.querySelector("#btn5").style.display = "none";

     document.querySelector("#rd1").addEventListener('click', function () {
         document.querySelector("#btn1").style.display = "block";
         document.querySelector("#btn3").style.display = "none";
         document.querySelector("#btn2").style.display = "none";
         document.querySelector("#btn4").style.display = "none";
         document.querySelector("#btn5").style.display = "none";
     });
     document.querySelector("#rd2").addEventListener('click', function () {
        document.querySelector("#btn1").style.display = "none";
        document.querySelector("#btn3").style.display = "none";
        document.querySelector("#btn2").style.display = "block";
        document.querySelector("#btn4").style.display = "none";
        document.querySelector("#btn5").style.display = "none";
     });
     document.querySelector("#rd3").addEventListener('click', function () {
        document.querySelector("#btn1").style.display = "none";
        document.querySelector("#btn2").style.display = "none";
        document.querySelector("#btn3").style.display = "block";
        document.querySelector("#btn4").style.display = "none";
        document.querySelector("#btn5").style.display = "none";
     });
     document.querySelector("#rd4").addEventListener('click', function () {
        document.querySelector("#btn1").style.display = "none";
        document.querySelector("#btn2").style.display = "none";
        document.querySelector("#btn3").style.display = "none";
        document.querySelector("#btn4").style.display = "block";
        document.querySelector("#btn5").style.display = "none";
     });
     document.querySelector("#rd5").addEventListener('click', function () {
        document.querySelector("#btn1").style.display = "none";
        document.querySelector("#btn2").style.display = "none";
        document.querySelector("#btn3").style.display = "none";
        document.querySelector("#btn4").style.display = "none";
        document.querySelector("#btn5").style.display = "block";
     });
 }

text();
</script>



</body>
</html>