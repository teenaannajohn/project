<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Country State City</title>
        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <style>
            body{
                background: #ccc;
            }
            form{
                background: #fff;
                padding: 30px;
                margin-top: 30px;
            }
            form h3{
                margin-top: 0;
            }
        </style>
    </head>

    <body>
        <div class="container">
            <div class="row">
                <!--Course -->
<script type="text/javascript">
function show(str)
{
if (str=="")
  {
  document.getElementById("txtHint").innerHTML="";
  return;
  } 
if (window.XMLHttpRequest)
  {// code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  }
else
  {// code for IE6, IE5
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
xmlhttp.onreadystatechange=function()
  {
 
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
   
    document.getElementById("txtHint").innerHTML=xmlhttp.responseText;
    }
  }
xmlhttp.open("GET","selectcity.php?cid="+str,true);

xmlhttp.send();
}
</script>
<?php
include("query.php");
$obj=new query();
?>
                <form action="" name="frm" method="post">
                    <h3>Country State City Dropdown</h3>
                    <section class="courses-section">
                        <div class="row">
                            <div class="col-md-4">
                                <select name="state"class="form-control"onchange="show(this.value)">
            <option value="">SELECT YOUR STATE</option>
            <?php
 

$res=$obj->selectsem();
while($r=mysqli_fetch_array($res))
{
  ?>
    <option value="<?php echo $r[0];?>"><?php echo $r[1];?></option>
    <?php
}
  ?>
  </select><br>
   <div id="txtHint" >
     
   </div>

                        </div>

                        </div>
                    </section>
                </form>
            </div>
        </div>
        
    </body>
</html>
