<?php

$id=$_GET['id'];
$con=mysqli_connect("localhost", "root", "", "exam","4306"); 
$q="select * from questions where qid='$id'";
$res=mysqli_query($con,$q);

echo "<select name=ddlstate>";
while($r=mysqli_fetch_array($res))
{
echo "<option value=".$r[0].">".$r['question']."</option>"; 
}
echo "</select>"
?>